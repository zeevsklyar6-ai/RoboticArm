6 DOF Robot Arm from DFRobot Arm by Lee1999 on Thingiverse: https://www.thingiverse.com/thing:7032384

Summary:
This is a rotation base I've designed for my robot arm kit that I've bought from the DFRobot Team.Please check the full Project here : https://youtu.be/bNzVCNyYDzM?si=KMS0LZEKwPrGHcwV